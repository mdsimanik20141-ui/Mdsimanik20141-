# Mohammad Shariful Islam Manik — Personal Website

A responsive bilingual (English/Bengali) personal portfolio starter designed for GitHub Pages.

## Files
- `index.html` — website content and structure
- `style.css` — responsive premium navy / ivory / gold styling
- `script.js` — language toggle and mobile navigation

## Before publishing
1. Your supplied portrait is included as `manik-profile.jpg`.
2. Your supplied email address and Facebook profile link are added.
3. Add LinkedIn / WhatsApp links if you want them displayed.
4. Review every biography, employer, role and education detail for accuracy.
5. Add real portfolio images and project links; current project cards are illustrative placeholders.

## Publish free with GitHub Pages
1. Sign in or create an account at https://github.com/
2. Create a **public** repository named exactly `YOUR-USERNAME.github.io`.
3. Upload `index.html`, `style.css`, and `script.js` to the repository root.
4. Open repository **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for the deployment to finish. Your site will be available at `https://YOUR-USERNAME.github.io/`.

GitHub Pages is free for public repositories. A custom `.com` domain is optional and usually costs money.

## Google search setup
1. Replace `YOUR-USERNAME.github.io` in `sitemap.xml` and `robots.txt` with your real site address (or custom domain).
2. Add the site in Google Search Console and verify ownership.
3. Submit `sitemap.xml` under Sitemaps, then use URL Inspection > Request indexing.
