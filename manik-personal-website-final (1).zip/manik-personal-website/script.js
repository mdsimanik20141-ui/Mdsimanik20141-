const toggle = document.getElementById('langToggle');
let currentLang = 'en';
function setLanguage(lang){
  currentLang = lang;
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-en][data-bn]').forEach(el=>{
    el.innerHTML = el.dataset[lang];
  });
  toggle.textContent = lang === 'en' ? 'বাংলা' : 'English';
  toggle.setAttribute('aria-label', lang === 'en' ? 'Switch to Bengali' : 'Switch to English');
}
toggle.addEventListener('click',()=>setLanguage(currentLang === 'en' ? 'bn' : 'en'));
document.getElementById('year').textContent = new Date().getFullYear();
const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');
menuToggle.addEventListener('click',()=>nav.classList.toggle('open'));
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));
